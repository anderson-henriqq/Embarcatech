#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "ssd1306.h"
#include "hardware/adc.h"  // Biblioteca para manipulação do ADC no RP2040 
#include "hardware/pwm.h"  // Biblioteca para controle de PWM no RP2040
#include "hardware/clocks.h"
#include "buzzer_pwm1.h"  // Inclua o arquivo de cabeçalho buzzer_pwm1.h


// Definições para o display OLED
#define I2C_PORT i2c1         // Porta I2C utilizada
#define PINO_SCL 14           // Pino de Clock do I2C
#define PINO_SDA 15           // Pino de Dados do I2C

ssd1306_t disp;               // Estrutura para o controle do display OLED

// Definição dos pinos usados para o joystick e LEDs 
const int VRX = 26;          // Pino de leitura do eixo X do joystick (conectado ao ADC)
const int VRY = 27;          // Pino de leitura do eixo Y do joystick (conectado ao ADC)
const int ADC_CHANNEL_0 = 0; // Canal ADC para o eixo X do joystick
const int ADC_CHANNEL_1 = 1; // Canal ADC para o eixo Y do joystick
const int SW = 22;           // Pino de leitura do botão do joystick

// Definições para o menu
#define NUM_OPCOES 3
const char *opcoes[NUM_OPCOES] = {"Opcao 1", "Opcao 2", "Opcao 3"};
int opcao_selecionada = 0;  // Inicia na primeira opção

// Função para configurar o joystick (pinos de leitura e ADC)
void setup_joystick()
{
  // Inicializa o ADC e os pinos de entrada analógica
  adc_init();         // Inicializa o módulo ADC
  adc_gpio_init(VRX); // Configura o pino VRX (eixo X) para entrada ADC
  adc_gpio_init(VRY); // Configura o pino VRY (eixo Y) para entrada ADC

  // Inicializa o pino do botão do joystick
  gpio_init(SW);             // Inicializa o pino do botão
  gpio_set_dir(SW, GPIO_IN); // Configura o pino do botão como entrada
  gpio_pull_up(SW);          // Ativa o pull-up no pino do botão para evitar flutuações
}

// Função para inicializar o display OLED
void inicializa_oled() {
    stdio_init_all(); // Inicializa a comunicação serial padrão
    i2c_init(I2C_PORT, 400 * 1000); // Configura o I2C na frequência de 400 kHz
    gpio_set_function(PINO_SCL, GPIO_FUNC_I2C); // Configura o pino SCL como função I2C
    gpio_set_function(PINO_SDA, GPIO_FUNC_I2C); // Configura o pino SDA como função I2C
    gpio_pull_up(PINO_SCL); // Ativa o pull-up no pino SCL
    gpio_pull_up(PINO_SDA); // Ativa o pull-up no pino SDA
    disp.external_vcc = false; // Configuração de energia do display (usando VCC interno)
    ssd1306_init(&disp, 128, 64, 0x3C, I2C_PORT); // Inicializa o display OLED com resolução 128x64
}

// Função para ler o valor do joystick (eixo X)
int ler_joystick_x() {
    uint16_t raw_value = adc_read();  // Lê o valor bruto do ADC (0-4095)
    return raw_value;
}

// Função para atualizar o menu no OLED
void atualizar_menu() {
    ssd1306_clear(&disp);  // Limpa o display

    // Exibe as opções do menu
    for (int i = 0; i < NUM_OPCOES; i++) {
        if (i == opcao_selecionada) {
            // Exibe o marcador de seleção
            ssd1306_draw_string(&disp, 10, i * 15, 1, "-> ");
        } else {
            ssd1306_draw_string(&disp, 10, i * 15, 1, "   ");
        }
        ssd1306_draw_string(&disp, 30, i * 15, 1, opcoes[i]);
    }

    ssd1306_show(&disp);  // Exibe o conteúdo no display
}

// Função principal
int main() {
    stdio_init_all();  // Inicializa a comunicação serial padrão
    setup_joystick();  // Configura o joystick
    inicializa_oled(); // Inicializa o display OLED

    while (1) {
        // Lê o valor do eixo X do joystick
        int leitura_joystick = ler_joystick_x();

        // Navegação no menu: se o valor do eixo X for menor que 1500, move para a direita; 
        // se for maior que 3500, move para a esquerda
        if (leitura_joystick < 1500) {
            opcao_selecionada = (opcao_selecionada + 1) % NUM_OPCOES; // Move para a direita
            sleep_ms(200);  // Atraso para evitar múltiplas mudanças rápidas
        } else if (leitura_joystick > 3500) {
            opcao_selecionada = (opcao_selecionada - 1 + NUM_OPCOES) % NUM_OPCOES; // Move para a esquerda
            sleep_ms(200);  // Atraso para evitar múltiplas mudanças rápidas
        }

        // Verificação do botão do joystick para seleção
        if (gpio_get(SW) == 0) {  // O botão é pressionado quando o valor é baixo
            printf("Opção selecionada: %s\n", opcoes[opcao_selecionada]);  // Exibe a opção selecionada no terminal

            // Se a opção selecionada for a 2, executa a função play_star_wars
            if (opcao_selecionada == 1) { // Se a opção 2 (index 1) for selecionada
                play_star_wars(21); // Chama a função play_star_wars passando o pino 21 (pino do buzzer)
            }

            sleep_ms(500);  // Atraso para evitar múltiplas seleções
        }

        atualizar_menu();  // Atualiza o menu no OLED
        sleep_ms(100);  // Atraso para melhorar a resposta e evitar leituras rápidas
    }

    return 0;
}
