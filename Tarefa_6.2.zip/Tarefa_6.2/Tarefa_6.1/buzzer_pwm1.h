#ifndef BUZZER_PWM1_H
#define BUZZER_PWM1_H

// Função para tocar a música tema Star Wars
void play_star_wars(uint pin);

#endif
